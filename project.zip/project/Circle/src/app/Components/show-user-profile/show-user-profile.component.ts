import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-user-profile',
  templateUrl: './show-user-profile.component.html',
  styleUrls: ['./show-user-profile.component.css']
})
export class ShowUserProfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
