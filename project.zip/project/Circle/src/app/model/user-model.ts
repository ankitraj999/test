export class User{
    id:number
    firstName:string
    lastName:string
    username:string
    email:string
    password:string
}
export class Message{
    sender:number
    receiver:Number
    msg:string
    TimeNdate:Date
    id?:number
   
}