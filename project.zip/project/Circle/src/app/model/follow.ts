export class Follow{
    
      reqSentBy: string
       reqSentTo: string
  }