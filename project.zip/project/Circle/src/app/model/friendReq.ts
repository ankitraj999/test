export class Request{

    ReqBy:string
     ReqTo:String
    
   
  
      }